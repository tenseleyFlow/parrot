package main

import (
	"parrot/cmd"
)

func main() {
	cmd.Execute()
}